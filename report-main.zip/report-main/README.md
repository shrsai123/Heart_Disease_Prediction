# report
Report and Project documentation

1. Initial Proposal: 2/7/25
2. EDA - Framingham: late February
3. Model Training - Framingham: late February
4. Project TA Check-in 1 with Jason: 2/28, 3/10
5. Professor Office Hours Check-in: 3/18
   - Continue with comparative analysis on Framingham and UCI datasets. Can use the Cleveland sub-dataset as the most complete.
   - If we have time, build and train a heart disease type classifier. 
6. 
