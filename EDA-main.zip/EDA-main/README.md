# EDA
Exploratory Data Analysis (Amanda)

1. Framingham Dataset (moved to separate folder)

2. UCI Dataset

