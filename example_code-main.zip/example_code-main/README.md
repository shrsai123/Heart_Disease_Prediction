# example_code
Reference code from existing Data Analysis performed on heart disease datasets.


1. UCI full Git repo clone
2. Feature engineering and missing data
3. heart disease eda
4. cornonary heart disease prediction
