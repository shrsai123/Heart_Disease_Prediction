# data


1. Initial cleaning and preprocessing tested on a few cardiac datasets 2/26/25. Decided the Framingham dataset would be the best suited for training models.
Cleaning and preprocessing the raw Framingham dataset.

2. 3/19/25: Going to redo our Framingham analysis on the Cleveland dataset.
