**First round of Exploratory Data Analysis performed on Framingham dataset.**
