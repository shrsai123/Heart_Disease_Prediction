# code
Model Training Code (Shreyas, Devansh)

Datasets
1. Framingham
2. Cleveland

Models:
- Logistic Regression
- XGBoost
- KNN
- Random Forest
- Neural Networks

